package com.pluralsight.service;

import com.pluralsight.model.Customer;

import java.util.List;

/**
 * Created by auntb on 2/27/2016.
 */
public interface CustomerService {
    List<Customer> findAll();
}
