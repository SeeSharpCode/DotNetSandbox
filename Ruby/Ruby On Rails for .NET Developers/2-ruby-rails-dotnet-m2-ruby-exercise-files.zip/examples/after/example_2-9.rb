employees = Hash.new

scores = { "john" => 100, "mary" => 200 }

puts scores["john"]

scores["tom"] = 300

puts scores
