s1 = "Hello\nWorld"
s2 = 'Hello\nWorld'
s3 = '.NET'
s4 = "Ruby on Rails for #{s3} Developers"
s5 = "Ruby on Rails for " + s3 + " Developers"

puts s1
puts s2
puts s4
puts s5
