colors = ['green', 'purple', 'red', 'blue', 'black', 'pink']

colors.delete('green')
colors.delete_at(2)

puts colors