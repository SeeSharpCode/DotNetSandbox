puts true.class
puts 1.class
puts "hello".class