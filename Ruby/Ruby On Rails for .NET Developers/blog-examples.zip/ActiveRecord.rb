require 'rubygems'
require 'active_record'

class Event < ActiveRecord::Base
  belongs_to :location
  has_and_belongs_to_many :attendees
end

class Attendee < ActiveRecord::Base
  self.primary_key = 'attid'
  has_and_belongs_to_many :events

  validates :firstname, :lastname, :format => {:with => /\A[A-Za-z]+\z/, :message => "Only a-z allowed"}
  validates :firstname, :lastname, :length => { :minimum => 2, :maximum => 20, :too_short => "Must be at least 2 characters", :too_long => "%{count} letters is too many"}
end

class Location < ActiveRecord::Base
  has_many :events
end

ActiveRecord::Base.establish_connection(:adapter => 'sqlserver',
                                            :database => 'ActiveRecordDemo',
                                            :dataserver => '127.0.0.1\SQLEXPRESS',
                                            :username => 'sa',
                                            :password => '1234')

#Query
attendees = Attendee.all
george = Attendee.where(:firstname => 'George')[0]

#Update
george.lastname = 'Washington'
george.save

#Delete
attendees[0].delete

#Validation
att = Attendee.create(:firstname => 'Dougggggggggggggggggggggggggggggggggggggggggggggg', :lastname => 'Smith')

if att.valid? == false
  att.errors.each do |e|
    puts "#{e} #{att.errors[e]}"
  end
end

ActiveRecord::Base.connection.close