class Person

	puts "Hi, I'm Joe!"

	def Speak
		puts "Hi, I'm Ted!"		
	end

end