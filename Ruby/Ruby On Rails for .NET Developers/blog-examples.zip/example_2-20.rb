
5.times do |i|
  puts i
end


1.upto 3 do |i|
  puts i
end

3.downto 1 do |i|
  puts i
end