def add
  x = 1+2
end

puts add