im_a_local_variable = 10

class ThisIsAClass

end

cONST_VARIABLE = 100

cONST_VARIABLE = 20
